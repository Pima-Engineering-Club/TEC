# Code of Conduct

SerialPort follows the Nodebots Code of Conduct. The full text can be found at http://nodebots.io/conduct.html

## TLDR
- Be respectful.
- Abusive behavior is never tolerated.
- Data published to NodeBots is hosted at the discretion of the service administrators, and may be removed.
- Don't build evil robots.
- Violations of this code may result in swift and permanent expulsion from the NodeBots community.
