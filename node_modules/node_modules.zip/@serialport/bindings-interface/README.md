# @serialport/bindings-interface

[![Release](https://github.com/serialport/bindings-interface/actions/workflows/test.yml/badge.svg)](https://github.com/serialport/bindings-interface/actions/workflows/test.yml)

SerialPort Bindings Typescript Types.

All issues should be filed on [the main node serialport repo](github.com/serialport/node-serialport/)
