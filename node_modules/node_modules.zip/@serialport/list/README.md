# @serialport/list

See our api docs https://serialport.io/docs/bin-list
